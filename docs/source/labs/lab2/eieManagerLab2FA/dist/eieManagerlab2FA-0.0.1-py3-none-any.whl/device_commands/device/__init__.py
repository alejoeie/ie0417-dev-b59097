"""
device_commands module entry point
"""

__author__ = 'Alejandro Zuniga Perez'
__email__ = 'alezph96@gmail.com'
__version__ = '0.0.1'
