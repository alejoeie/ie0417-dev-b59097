"""

eieManager module entry point

"""
__authors__ = "Alejandro Zuniga Perez, Fabricio "
__email__ = "alezph96@gmail.com"
__version__ = '0.0.1'
