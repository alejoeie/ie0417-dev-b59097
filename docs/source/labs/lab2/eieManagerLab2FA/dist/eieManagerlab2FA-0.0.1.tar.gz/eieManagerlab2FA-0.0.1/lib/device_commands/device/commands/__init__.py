"""
sensor_commands module entry point.
"""
