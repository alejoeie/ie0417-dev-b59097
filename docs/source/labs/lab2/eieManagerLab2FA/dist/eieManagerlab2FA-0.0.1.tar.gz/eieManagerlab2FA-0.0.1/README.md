# EieManager package

This is a package for the EieManager module. 
